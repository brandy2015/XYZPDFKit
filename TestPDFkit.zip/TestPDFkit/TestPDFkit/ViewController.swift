
import UIKit
import XYZPDFKit

class ViewController: UIViewController {
    
    @IBOutlet var collectionView:PDFSinglePageViewer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        let url = Bundle.main.path(forResource: "sample", ofType: "pdf")!
        let document = try! PDFDocument(filePath: url, password: "")
        
        self.collectionView.document = document
    }
}

